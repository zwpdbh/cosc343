/**
 * Created by zw on 5/6/16.
 */
public enum Direction {
    UP, DOWN, LEFT, RIGHT
}
